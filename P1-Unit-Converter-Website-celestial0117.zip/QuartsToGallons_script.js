let gallons = (((prompt("Enter quarts")) * 0.453)); 

  console.log("This converts to " + gallons + "gallons.");

  alert ("This converts to " + gallons + " gallons."); 