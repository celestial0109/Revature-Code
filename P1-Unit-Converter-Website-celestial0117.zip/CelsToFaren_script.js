let farenheit = ((1.8 * (prompt("Enter Celsius")) + 32)); 

  console.log("The temperature is " + farenheit + "degrees Farenheit.");

  alert ("The temperature is " + farenheit + " degrees Farenheit."); 


