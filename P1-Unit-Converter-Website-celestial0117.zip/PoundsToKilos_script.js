let kilos = (((prompt("Enter pounds")) * 0.453)); 

  console.log("This converts to " + kilos + "kilos.");

  alert ("This converts to " + kilos + " kilos."); 