# Lesson plan
  
## Requirements

* 5 HTML pages
  * index.html
  * 4 conversion pages of your choice
* menus in all of your webpages and sections with information in each of your conversion pages
* a style.css file
  * a CSS rule that styles your menu to float left and have a width of no more than 20% of the window
  * ensure that the sections is to the right of the menus
* 4 `<script>` elements, one in each conversion page
  * you use prompt() and alert() to interact with the user
  * you correctly convert from one unit to another
  