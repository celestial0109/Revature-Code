# Instructions  

It's time to combine everything you know about HTML and CSS to create a website for converting between different units of measurement, like converting from fahrenheit to celsius, cups to teaspoons, or leagues to furlongs.

  ## Steps
  1. Create an HTML file named **index.html**. This file is the home page of the website. Give this HTML page a menu that will contain a list of links to other HTML pages you will create. 
    * Note: "menu" is not a technical term. You can choose any HTML element that allows you to contain other elements within it.
  <br><br>
  2. Create four new HTML pages. Each of these pages will represent a unit of measurement conversion of your choice. For example, if I want to have a webpage about converting from fahrenheit to celsius, I would create an HTML page named *FahrenheitToCelsius.html*.
  <br><br>
  3. In each of these conversion pages, add in a menu that has links back to the home page as well as to the other conversion pages. Update the home page's menu to contain links to the four different conversion pages.
  <br><br>
  4. In each of the conversion pages, create a section that will appear to the right of the menu. In this section, display the formula for the respective conversion. For example, if I had a *FahrenheitToCelsius.html* webpage, I could have the formula: *(32°F − 32) × 5/9 = 0°C* displayed to the user.
 Additionally, write a little bit of history or information about the two units. It's fine if you copy and paste the information from an external resource.
  <br><br>
  5. Next, create a CSS file named **style.css**. Add in a CSS rule that styles the menus so that they float to the left and occupy no more than 20% of the width of the screen. Make sure to link your CSS file to your HTML file.
   <br><br>
  6. If necessary, add in another CSS rule so that the section to the right of the menu is beside it, not underneath it. 
  <br><br>
  Here is an example of what your website could look like at this point:
  <br><br>
  ![part 1 example gif](assets/p1-part1-example.gif)
  <br><br>
  Make sure to put actual formulas and information in the webpages!
  <br><br>
  7. Moving on to JavaScript, create `<script>` elements in each of your conversion pages.
   <br><br>
  8. In each `<script>` element, use the prompt() function to ask the user to enter the amount of units they would like to convert.
   <br><br>
  9. Convert the user's input into the corresponding unit of measurement and then use the alert() function to display the results to the user.
  <br><br>
  Here is an example of what it could look like after adding in the JavaScript:
  <br><br>
  ![part 2 example gif](assets/p1-part2-example.gif)
   <br><br>
   10. You can now optionally continue to add more HTML or CSS to make it look even better!
   
## Requirements
Once you are done with your project, check it against the requirements below to make sure you have included everything:
* 5 HTML pages
  * index.html
  * 4 conversion pages of your choice
* menus in all of your webpages and sections with information in each of your conversion pages
* a style.css file
  * a CSS rule that styles your menu to float left and have a width of no more than 20% of the window
  * ensure that the sections are to the right of the menus
* 4 `<script>` elements, one in each conversion page
  * you use prompt() and alert() to interact with the user
  * you correctly convert from one unit to another
  
