let inches = ((Math.round(prompt("Enter centimeters")) * 0.393)); 

  console.log("This converts to " + inches + "inches.");

  alert ("This converts to " + inches + " inches."); 